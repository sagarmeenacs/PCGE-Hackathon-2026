# AeroPath Emergency Operations

A responsive emergency-response operations workspace built with React, Vite, TypeScript, Leaflet, and lucide-react. The accessible interface uses larger type, high-contrast navy navigation, and phone-sized controls.

## Run locally

1. Install Node.js 20 or newer.
2. From this folder, run `npm ci`.
3. Run `npm run dev` and open the local URL printed by Vite.
4. Run `npm run build` to create a production bundle in `dist/`.

## Demo scope

The application uses fictional, in-memory demonstration data. Ambulance simulation, patient handover, hospital matching and capacity controls, family update logging, editable profile details, and saved notification preferences are provided locally in the browser. It does not connect to emergency services, contact families, or persist patient data beyond this browser profile.
